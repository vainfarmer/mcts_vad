"""Adapt the existing BUE/CBT implementations into isolated boundary proposals.

The search category is frozen to the predicted category, never a dataset label.
Each operator gets its own detection copy; siblings cannot modify each other.
"""
import copy


class BueCbtActions:
    def __init__(self, bue, cbt, video_data, category, seed):
        self.operators = (('bue', bue), ('cbt', cbt))
        self.data = video_data
        self.category = category
        self.template = copy.deepcopy(seed)
        self.template['anomaly_type'] = category
        self.template.setdefault('confidence', 0.)

    def __call__(self, interval):
        proposals = []
        for name, operator in self.operators:
            detection = copy.deepcopy(self.template)
            detection['t_start'], detection['t_end'] = interval
            rows = operator([detection], self.data, self.category)
            if len(rows) != 1:
                raise ValueError('Boundary operators must preserve detection count')
            proposals.append((name, (float(rows[0]['t_start']), float(rows[0]['t_end']))))
        return proposals
