"""原始视频FPS索引。严格检查缺失项，避免静默退回30fps。"""
from collections.abc import Mapping
import json
import math
from pathlib import Path

DEFAULT_MANIFEST = Path(__file__).resolve().parents[1] / 'data' / 'ucf_crime_test_video_fps.json'


def load_fps_manifest(path=DEFAULT_MANIFEST, required_ids=()):
    obj = json.loads(Path(path).read_text(encoding='utf-8'))
    if obj.get('schema') != 'video-fps-v1':
        raise ValueError('Unsupported video FPS manifest schema')
    result = {}
    for name, item in obj['videos'].items():
        value = float(item['fps'])
        if not math.isfinite(value) or value <= 0:
            raise ValueError(f'Invalid FPS for {name}: {value}')
        result[name] = value
    missing = set(required_ids) - result.keys()
    if missing:
        raise ValueError(f'FPS manifest missing videos: {sorted(missing)}')
    return result


def fps_for_video(fps, video_id):
    value = float(fps[video_id] if isinstance(fps, Mapping) else fps)
    if not math.isfinite(value) or value <= 0:
        raise ValueError(f'Invalid FPS for {video_id}: {value}')
    return value


def evaluation_fps(fallback, manifest, required_ids):
    """None自动使用项目索引；False仅供显式复现旧固定FPS指标。"""
    if manifest is False:
        return fallback
    target = Path(manifest) if manifest is not None else DEFAULT_MANIFEST
    # 默认索引丢失也不回退固定30fps；历史复现必须显式选择False。
    return load_fps_manifest(target, required_ids)
