"""只读v217已有主结果与配对off结果，离线按逐视频FPS重评；不调用模型/API。"""
import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import pandas as pd
from .temporal_ap import compute_legacy_map, compute_vadclip_map
from .video_fps import source_video_metadata


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path,payload):
    path.write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding='utf-8')


def main():
    root=Path(__file__).resolve().parents[1]
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--experiment',type=Path,default=root/'vad_v3/experiments/v217')
    parser.add_argument('--video_root',type=Path,default=Path('F:/dataset/ucf_crime'))
    parser.add_argument('--labels',type=Path,default=Path('F:/dataset/ucf_crime/data_parquet/test-00000-of-00001.parquet'))
    parser.add_argument('--output_dir',type=Path,default=root/'vad_v3/experiments/v217/reevaluation_source_video_fps')
    args=parser.parse_args()
    selected=json.loads((args.experiment/'selected_videos.json').read_text(encoding='utf-8'))
    names={Path(x['video_path']).stem for x in selected}
    if len(names)!=290 or len(selected)!=290:
        raise ValueError('Expected exactly 290 distinct selected videos')
    metadata=source_video_metadata({Path(x['video_path']).stem:x['video_path'] for x in selected},
                                   video_root=args.video_root)
    fps={name:row['fps'] for name,row in metadata.items()}
    gt={}
    for row in pd.read_parquet(args.labels).to_dict('records'):
        name=Path(row['video_path']).stem
        if name in gt:
            raise ValueError('Duplicate GT video')
        gt[name]=dict(category=row['category'],segments=[(int(row[f'annotation_start{i}']),int(row[f'annotation_end{i}']))
            for i in (1,2) if row[f'annotation_start{i}']>=0 and row[f'annotation_end{i}']>=0])
    if set(gt)!=names:
        raise ValueError('Selection must match original parquet test set exactly')
    predictions={'main_on':{},'paired_original_off':{}}
    hashes={}
    for path in sorted((args.experiment/'results').glob('*.json')):
        obj=json.loads(path.read_text(encoding='utf-8'))
        if 'video_path' not in obj or 'anomalies' not in obj:
            continue
        name=Path(obj['video_path']).stem
        if name in predictions['main_on']:
            raise ValueError('Duplicate result video')
        predictions['main_on'][name]=obj
        predictions['paired_original_off'][name]=obj['paired_results']['original_off']
        hashes[path.name]=digest(path)
        if abs(obj['duration']-metadata[name]['duration'])>1e-6:
            raise ValueError('Stored prediction duration does not match native video timebase')
    if any(set(arm)!=names for arm in predictions.values()):
        raise ValueError('Incomplete result coverage')
    args.output_dir.mkdir(parents=True,exist_ok=True)
    report=dict(created_at=datetime.now(timezone.utc).isoformat(),schema='v217-vadclip-reevaluation-v1',
        source_results=str((args.experiment/'results').resolve()),fps_source='original_video_files',
        source_video_metadata=metadata,labels=str(args.labels.resolve()),labels_sha256=digest(args.labels),
        metadata_summary=dict(video_count=len(metadata),fps_counts=dict(Counter(fps.values()))),
        video_categories=dict(Counter(v['category'] for v in gt.values())),
        protocol=dict(name='VadCLIP paper scope with official rank-AP formula on existing detections',
            scope='140 abnormal videos; macro-average over 13 anomaly categories',
            thresholds=[.1,.2,.3,.4,.5],ap='sum(precision_at_rank * TP) / number_of_GT_segments',
            matching='Same video and category; descending confidence; one-to-one greedy highest unmatched IoU',
            timebase='prediction [int(start_seconds*video_fps), int(end_seconds*video_fps)); GT [start_frame,end_frame)',
            tie_break='video_id, start_frame, end_frame, category, original_prediction_index',
            units='values and per_class AP: fractions 0..1; percent: 0..100',
            gt_policy='Keep original GT, including five end-frame overshoots of 1-2 frames; no silent clipping',
            prediction_policy='Keep v217 final boundaries, labels and confidence; no new proposals, NMS, API or inference',
            upstream_difference='Official repo current ucf_test.py passes excludeNormal=False and averages 14 classes; excludeNormal=True still loops 14. Paper states abnormal videos only. Main result follows paper 140/13, not those code inconsistencies.',
            limitation='v217 lacks VadCLIP per-class dense logits; this adapts its evaluation formula, not its proposal extraction or model results.'),
        references=dict(paper='https://arxiv.org/html/2308.11681v3',
            official_code='https://github.com/nwpu-zxr/VadCLIP/blob/c41067f07d252efcda18008bea367886070c33b0/src/utils/ucf_detectionMAP.py'),arms={})
    for name,arm in predictions.items():
        native,audit=compute_vadclip_map(gt,arm,fps)
        fixed,_=compute_vadclip_map(gt,arm,30.)
        extended,_=compute_vadclip_map(gt,arm,fps,include_normal_videos=True)
        legacy_fixed=compute_legacy_map(gt,arm,30.)
        legacy_native=compute_legacy_map(gt,arm,fps)
        report['arms'][name]=dict(vadclip_paper_native_fps=native,vadclip_paper_fixed30_control=fixed,
            supplemental_all290_13class_native_fps=extended,
            legacy_fixed30_recomputed=legacy_fixed,legacy_native_fps_control=legacy_native,
            fps_only_delta={k:legacy_native[k]-legacy_fixed[k] for k in legacy_fixed})
        save(args.output_dir/f'{name}_matching_audit.json',audit)
    original=json.loads((args.experiment/'results/evaluation_report.json').read_text(encoding='utf-8'))
    report['historical_stored_main_temporal_map']=original['evaluation']['temporal_map']
    save(args.output_dir/'ap_results.json',report)
    save(args.output_dir/'input_hashes.json',dict(prediction_files=hashes,evaluation_source_files={
        p.name:digest(p) for p in Path(__file__).resolve().parent.glob('*.py')}))
    # Ensure offline evaluation did not modify any original prediction.
    assert all(digest(args.experiment/'results'/name)==sha for name,sha in hashes.items())
    print(json.dumps({name:{'vadclip_paper_percent':v['vadclip_paper_native_fps']['percent'],
        'legacy_fps_control':v['legacy_native_fps_control']} for name,v in report['arms'].items()},indent=2))
    print(args.output_dir/'ap_results.json')


if __name__=='__main__':
    main()
