"""Shared, offline video metadata and evaluation utilities."""
