"""读取测试视频的原始流FPS及帧数，生成可重复使用的JSON索引；不做模型推理。"""
import argparse
from collections import Counter
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from fractions import Fraction
import hashlib
import json
import math
from pathlib import Path
import cv2


def probe(row, result_dir=None):
    path = Path(row['video_path']).resolve(strict=True)
    cap = cv2.VideoCapture(str(path))
    try:
        if not cap.isOpened():
            raise ValueError(f'Cannot open video: {path}')
        fps = float(cap.get(cv2.CAP_PROP_FPS))
        count = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        width, height = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH)), int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        backend = cap.getBackendName()
    finally:
        cap.release()
    if not math.isfinite(fps) or fps <= 0 or count <= 0:
        raise ValueError(f'Invalid video metadata: {path}')
    gt_end = max(row.get('annotation_end1', -1), row.get('annotation_end2', -1))
    stat = path.stat()
    item = dict(video_path=str(path), category=row['category'], fps=fps,
        fps_rational_approx=str(Fraction(fps).limit_denominator(1000000)), frame_count=count,
        duration_seconds=count/fps, width=width, height=height, backend=backend,
        file_size_bytes=stat.st_size, file_mtime_ns=stat.st_mtime_ns,
        max_gt_end_frame=gt_end, gt_within_frame_count=gt_end <= count)
    if result_dir:
        result = json.loads((Path(result_dir)/(path.stem+'.json')).read_text(encoding='utf-8'))
        item['prediction_duration_seconds'] = result['duration']
        item['prediction_duration_error_seconds'] = abs(result['duration']-count/fps)
    return path.stem, item


def main():
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--selected', type=Path, default=root/'vad_v3/experiments/v217/selected_videos.json')
    parser.add_argument('--result_dir', type=Path, default=root/'vad_v3/experiments/v217/results')
    parser.add_argument('--output', type=Path, default=root/'data/ucf_crime_test_video_fps.json')
    parser.add_argument('--workers', type=int, default=4)
    args = parser.parse_args()
    selected = json.loads(args.selected.read_text(encoding='utf-8'))
    if len({Path(x['video_path']).stem for x in selected}) != len(selected):
        raise ValueError('Duplicate video identifiers')
    with ThreadPoolExecutor(max_workers=args.workers) as pool:
        videos = dict(pool.map(lambda row: probe(row, args.result_dir), selected))
    summary = dict(video_count=len(videos), fps_distribution=dict(Counter(str(v['fps']) for v in videos.values())),
        non_30fps=sum(not math.isclose(v['fps'],30,abs_tol=1e-6) for v in videos.values()),
        abnormal_non_30fps=sum(v['category']!='Normal' and not math.isclose(v['fps'],30,abs_tol=1e-6) for v in videos.values()),
        gt_out_of_bounds=[k for k,v in videos.items() if not v['gt_within_frame_count']],
        max_prediction_duration_error_seconds=max(v.get('prediction_duration_error_seconds',0) for v in videos.values()))
    payload = dict(schema='video-fps-v1', created_at=datetime.now(timezone.utc).isoformat(),
        source_selected=str(args.selected.resolve()), source_selected_sha256=hashlib.sha256(args.selected.read_bytes()).hexdigest(),
        method='OpenCV VideoCapture CAP_PROP_FPS/CAP_PROP_FRAME_COUNT (same timebase as pipeline)',
        limitation='Stream FPS metadata, not per-frame PTS. Constant-rate conversion matches existing pipeline; VFR is not independently ruled out.',
        opencv_version=cv2.__version__, summary=summary, videos=dict(sorted(videos.items())))
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(summary,ensure_ascii=False,indent=2))
    print(args.output)


if __name__ == '__main__':
    main()
